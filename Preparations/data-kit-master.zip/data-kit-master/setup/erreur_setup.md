# Erreurs fréquentes

Il arrive que des erreurs surviennent lors de l'installation. 

Nous listons dans ce document les erreurs les plus fréquentes. N'hésitez pas à contribuer ! 

## Mac OSX

## Windows

